package com.mutualbooks.app;

import java.sql.*;

public class UserManager {

	 public int doRegister(User newUser) {
		 Connection dbcon = getDBConnection();
		 try {
			 Statement stmt = dbcon.createStatement();
			 String strsql="select max(UserID) from user_cred";
			 ResultSet rs = stmt.executeQuery(strsql);
			 int id = 0;
			 while(rs.next()) {
				 id = rs.getInt(1);
				 System.out.println(id);
			 }
			 id++;
			 newUser.setUserID(id);
			 strsql = "insert into user_details values("+id+",'"+newUser.getDisplayName()+"','"+newUser.getEmail()+"','"+newUser.getPhoneNumber()+"','"+newUser.getAddress()+"')";
			 
			stmt.executeUpdate(strsql);
			 
			 
			 strsql ="insert into user_cred values("+id+",'"+newUser.getLoginID()+"','"+newUser.getPassword()+"')";
			 stmt.executeUpdate(strsql);
			 dbcon.close();
			 return 1;
		 }catch(Exception e){System.out.println(e); 
		 return 0;
		 }
		
	}
	 
	 public boolean doLogin(String strLogin, String strPwd) {
		 Connection dbcon = getDBConnection();
		 boolean ret = false;
		 try {
		 Statement stmt=dbcon.createStatement();  
		 String strsql="select Password from user_cred where LoginID='"+strLogin+"'";
		 System.out.println(strsql);
		 ResultSet rs=stmt.executeQuery(strsql); 
		 String pwd=null;
		 while(rs.next()) {
			 pwd = rs.getString(1);
		 System.out.println(pwd); 
		 }
		System.out.println(strPwd);
		 if(pwd.equals(strPwd)) {
			 System.out.println("Login successfull!");
			 ret = true;
		 }
		 dbcon.close();
		 return ret;
		 }catch(Exception e) {System.out.println(e); 
		 return false;
		 }
	 }
	 
	 
	 
	 public Connection getDBConnection() {
		 Connection dbcon =null;
		try {
		 Class.forName("com.mysql.jdbc.Driver");  
		 dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookpublish","root","Daliarani123#");
		/* Statement stmt=dbcon.createStatement();  
		 ResultSet rs=stmt.executeQuery("select * from emp");  
		 while(rs.next()) 
		 System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
		 dbcon.close();*/
		 
		 }catch(Exception e){ System.out.println(e);}  
		return dbcon;
	 }
	
}

