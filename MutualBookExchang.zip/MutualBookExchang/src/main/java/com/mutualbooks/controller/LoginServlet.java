package com.mutualbooks.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mutualbooks.app.*;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//sponse.getWriter().append("Served at: ").append(request.getContextPath());
		String strRequestID;
		strRequestID = request.getParameter("reqID");
		if (strRequestID.equals("register")){
			int userStatus = doRegister(request, response);
			System.out.println("requesId userstatus"+userStatus);
			if (userStatus != 0)
			{
				request.setAttribute("result", "user created successfully");
			}
			else
			{
				request.setAttribute("result","failed to created user");
			}
			
		}
		if (strRequestID.equals("login")){
			
			boolean loginStatus = userLogin(request, response);
			if (loginStatus)
				request.setAttribute("result","user login successful");
			else
				request.setAttribute("result","user login not successful");
		}
		request.getRequestDispatcher("registeroutput.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private int doRegister(HttpServletRequest request, HttpServletResponse response)
	{
	    System.out.println("inside doRegiser");
		User newUser = new User();
		newUser.setLoginID(request.getParameter("loginID"));
		newUser.setPassword(request.getParameter("pwd"));
		newUser.setDisplayName(request.getParameter("displayname"));
		newUser.setEmail(request.getParameter("emailid"));
		newUser.setAddress(request.getParameter("address"));
		newUser.setPhoneNumber(request.getParameter("phone"));
		//User Manager 
		UserManager userMgr = new UserManager();
		int flag;
		flag = userMgr.doRegister(newUser);
		return flag;
	}
	
	private boolean userLogin(HttpServletRequest request, HttpServletResponse response) 
	{
		
		 System.out.println("inside user Login");
		 UserManager userMgr = new UserManager();
		 boolean status = userMgr.doLogin(request.getParameter("loginID"),request.getParameter("pwd"));
		 return status;
	}

}
